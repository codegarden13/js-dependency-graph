# MRI Graph Layout

Dieses Dokument beschreibt das **Layout und die Visualisierungslogik** des *Architecture MRI Graph* im NodeAnalyzer.

Der MRI‑Graph ist eine Diagnosevisualisierung für Softwarearchitektur.  
Er kombiniert Strukturinformationen (Module und Abhängigkeiten) mit Metriken aus der Analyse (`code-metrics.csv`).

Ziel des Layouts ist es, Architekturprobleme schnell sichtbar zu machen:

- starke Kopplungen
- große Module
- Hotspots
- Änderungsdruck

Der Graph ist **keine exakte Architekturkarte**, sondern ein Werkzeug zur **Architekturdiagnose**.

---

# Datenquelle code-metrics.csv

Die Visualisierung basiert auf der Datei

```
code-metrics.csv
```

Diese Datei wird bei jeder Analyse erzeugt und im Verzeichnis gespeichert:

```
/public/output
```

Beim Öffnen des MRI‑Tabs lädt die UI die **neueste passende Datei für die aktuelle AppID**.

Beispiel:

```
nodeanalyzer-2026-03-10T12-35-01-455Z-code-metrics.csv
```

---

# Datenstruktur

Die CSV enthält pro Modul eine Zeile.

Typische Spalten sind:

```
relation
kind
id
file
label
layer
lines
complexity
fanIn
fanOut
exported
imported
unused
hotspot
hotspotScore
changeFreq
lastTouchedAt
x
y
source
target
value
```

Diese Felder werden unterschiedlich im Graph verwendet.

#TODO:Erkläre die Verwendung der Felder im MRI

---

# Graph‑Struktur

Der Graph besteht aus:

- **Nodes** → Module / Dateien
- **Edges** → Abhängigkeiten

## Nodes

Jede Code‑Datei wird zu einem Node.

Erkennbar an typischen Dateiendungen:

```
.js
.ts
.jsx
.tsx
.mjs
.cjs
```

### Node Attribute

| Feld | Bedeutung |
|-----|-----------|
| `lines` | Größe des Moduls |
| `complexity` | Codekomplexität |
| `fanIn` | eingehende Abhängigkeiten |
| `fanOut` | ausgehende Abhängigkeiten |
| `hotspotScore` | Architektur‑Hotspot |
| `changeFreq` | Änderungsfrequenz |


### Node Darstellung

#TODO:Farblich besser absetzen

| Visualisierung | Bedeutung |
|---------------|----------|
| Kreisgröße | Anzahl Codezeilen (`lines`) |
| Farbe | Hotspot‑Score |
| Randstärke | `fanOut` |
| roter Halo | `changeFreq` |


---

# Edges (Abhängigkeiten)

Edges entstehen aus:

```
source → target
```


#TODO:edges sind bicht sichtbar

Diese definieren Import‑ oder Call‑Beziehungen zwischen Modulen.

Darstellung:

- dünne Linien
- halbtransparent

Viele Linien zwischen Modulen deuten auf **starke Kopplung**.

---

# Node Layout

Der Graph verwendet ein mehrstufiges Layout.

## 1 Koordinaten aus CSV

Wenn `x` und `y` existieren und genügend Streuung besitzen:

```
x
 y
```

werden diese Koordinaten direkt verwendet.

Vorteil:

- stabil
- reproduzierbar


## 2 Layer Layout

Falls ein `layer` Feld existiert, wird ein Architektur‑Layout erzeugt.

Beispiel:

```
config
helpers
services
routes
controllers
```

Jeder Layer wird horizontal angeordnet. Innerhalb des Layers werden Module nach einem **Importance Score** sortiert.


## 3 Force Layout (Fallback)

Wenn keine Koordinaten oder Layer vorhanden sind, wird ein Force Layout berechnet.

Kräfte:

```
forceManyBody
forceLink
forceCenter
forceCollide
```

Ziel:

- Überlappung vermeiden
- Struktur sichtbar machen


---

# Label Layout

Die Beschriftung folgt einem **Star‑Layout**.

Idee:

Der Graph bildet das Zentrum einer "Architekturkarte". Die wichtigsten Module werden außen beschriftet.


## Schritt 1 – wichtigste Module auswählen

Die wichtigsten Nodes werden anhand eines **Importance Score** bestimmt.

Der Score kombiniert typischerweise:

```
hotspotScore
changeFreq
complexity
lines
```

Nur die Top‑Module werden beschriftet.


## Schritt 2 – Zielposition bestimmen

Die Labels werden entlang eines festen Sternwinkels projiziert.

Im Code:

```
const STAR_ANGLE_DEG = 150
```

Dieser Winkel bestimmt die Richtung der Leader Lines.


## Schritt 3 – Labelspalte erzeugen

Alle Modul- Labels werden links am SVG Rand angeordnet.




## Schritt 4 – semantische Sortierung

Die vertikale Reihenfolge basiert auf der **Modulposition im Graph**.

Damit bleiben Module, die im Graph nah beieinander liegen, auch in der Labelspalte gruppiert.


## Schritt 5 – Kollisionsvermeidung

Ein zweiphasiger Algorithmus verhindert Überlappungen:

1️⃣ forward pass

```
top → bottom
```

2️⃣ backward pass

```
bottom → top
```

Danach werden Labels wieder leicht in Richtung ihrer Zielposition verschoben.


## Leader Lines

Jedes Label wird mit einer Linie zum Modul verbunden.

Dadurch entsteht ein **sternförmiges Layout**.


---

# Interpretation des Graph

Typische Muster:

### kompakter Cluster

Viele gegenseitige Abhängigkeiten.

Mögliche Ursachen:

- fehlende Modulgrenzen
- God Modules


### große Nodes

Große Dateien mit vielen Codezeilen.Refactoring Kandidaten.


### rote Nodes

Hoher Hotspot Score. Diese Module verursachen häufig Probleme.


### viele Edges

Starke Kopplung.

Typisch für Service Layer oder zentrale Infrastruktur.


---

# Optimierungspotential

Das aktuelle Layout funktioniert gut für kleine bis mittlere Projekte.

Bei sehr großen Projekten (>500 Module) können Verbesserungen sinnvoll sein.


## 1 Cluster Layout

Module könnten zusätzlich nach Ordnern gruppiert werden.

Beispiel:

```
controllers/
services/
helpers/
```


## 2 Architektur Heatmap

Layer könnten farblich hinterlegt werden.

Beispiel:

```
UI
Service
Core
Infrastructure
```


## 3 Edge Bundling

Viele Linien können schwer lesbar werden.Edge Bundling würde verwandte Kanten bündeln.


## 4 interaktive Filter

Mögliche Filter:

- nur Hotspots
- nur fanOut > N
- nur letzte Änderungen


## 5 Zoom‑abhängige Labels

Labels könnten abhängig vom Zoomlevel erscheinen.

So bleibt der Graph übersichtlich.


---

# Empfehlung

Das aktuelle Layout ist bereits **sehr sinnvoll für Architekturdiagnose**.

Es kombiniert:

- strukturelle Darstellung
- Metrikvisualisierung
- externe Labelstruktur

Der größte Nutzen entsteht durch die Kombination aus:

```
Graphstruktur
Hotspotindikatoren
Leader‑Label Layout
```

Für typische Node‑ oder Express‑Projekte kann das Layout **so belassen werden**. Optimierungen sind hauptsächlich bei sehr großen Systemen notwendig.

---

# Ziel des MRI Graph

Der Graph soll helfen zu beantworten:

- Wo liegen Architektur‑Hotspots?
- Welche Module sind zentral?
- Welche Teile des Systems sind instabil?
- Wo lohnt sich Refactoring?

Er ist damit ein Werkzeug für **Architecture Observability**.
