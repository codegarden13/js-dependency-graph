

# NodeAnalyzer – Node Rings (Rand / Stroke) Dokumentation

Diese Dokumentation beschreibt **wie**, **wann** und **durch welche Funktionen** die Node‑Ringe (Stroke / Border) im CodeGraph berechnet und gerendert werden.

Die Ringe transportieren Metadaten über die analysierte Codebasis, insbesondere:

- API‑Rolle (export / import / shared)
- Kopplung (Coupling) zwischen Funktionen und Modulen
- Aufrufhäufigkeit von Funktionen

Die Berechnung erfolgt vollständig im **Encoder‑Layer** und wird anschließend vom **Renderer** verwendet.

---

# 1 Architekturüberblick

Der Ablauf besteht aus drei Ebenen:

1. Graphdaten (Analyzer Output JSON)
2. Visual Encoding (`render.encoders.js`)
3. Rendering im D3 Graph

Pipeline:

Analyzer JSON

→ render.encoders.js

→ makeEncoders()

→ Renderer (d3_codeStructure.js)

→ SVG stroke / ring

Der Encoder übersetzt Rohmetriken aus dem Graphmodell in visuelle Eigenschaften.

---

# 2 Relevante Dateien

## Analyzer Output

Graphdaten enthalten unter anderem folgende Felder:

- `_inCalls`
- `_outCalls`
- `_inUses`
- `_outUses`
- `_inIncludes`
- `_outIncludes`
- `_inbound`
- `_outbound`
- `exported`

Diese Felder beschreiben **Abhängigkeiten zwischen Knoten**.

---

## Encoder Layer

Datei:

app/public/assets/js/codeGraph/render.encoders.js

Diese Datei ist verantwortlich für alle visuellen Encodings.

Dazu gehören:

- Node Farbe
- Node Radius
- Node Stroke Farbe
- Node Stroke Breite
- Function Ring Breite

Der Encoder wird über folgende Funktion bereitgestellt:

```
makeEncoders(nodes)
```

Der Renderer erhält anschließend ein Encoder‑Objekt.

---

### 3 Ringbreite für Funktionsknoten

Funktion:

```
getFunctionRingWidth(d)
```

Datei:

```
render.encoders.js
```

Diese Funktion bestimmt die sichtbare Ringbreite für Funktionsknoten.

Die Breite basiert auf **Call‑Coupling**.

Verwendete Felder:

```
_inCalls
_outCalls
```

Berechnung:

```
callCoupling = inboundCalls + outboundCalls
```

Danach erfolgt eine logarithmische Normalisierung:

```
spread01 = normalizeCoupling01(callCoupling)
```

Die finale Ringbreite liegt zwischen:

```
GRAPH_ENCODING.stroke.ringMin
GRAPH_ENCODING.stroke.ringMax
```

Standardwerte:

```
1 – 12 px
```

Damit werden häufig aufgerufene Funktionen visuell hervorgehoben.

---

### 4 Stroke Farbe (API Rolle)

Funktion:

```
computeNodeStroke(d)
```

Diese Funktion bestimmt die **Randfarbe eines Knotens**.

Die Rolle wird über folgende Funktion bestimmt:

```
getNodeBorderRole(d)
```

Mögliche Rollen:

| Rolle | Bedeutung |
|-----|-----|
| default | interne Funktion |
| imported | Funktion wird benutzt |
| exported | API / Export |
| shared | importiert und exportiert |

Mapping:

| Rolle | Farbe |
|-----|-----|
| exported | grün |
| imported | blau |
| shared | türkis |
| default | grau |

Sonderfall:

```
_changed === true
```

→ roter Rand

---

### 5 Stroke Breite

Funktion:

```
computeNodeStrokeWidth(d)
```

Die Randbreite basiert auf **Gesamtkopplung**.

Dazu werden mehrere Metriken kombiniert.

```
inboundTotal =
  _inCalls
+ _inUses
+ _inIncludes
+ _inbound

outboundTotal =
  _outCalls
+ _outUses
+ _outIncludes
+ _outbound
```

Gesamtkopplung:

```
coupling = inboundTotal + outboundTotal
```

Normalisierung:

```
normalizeCoupling01(coupling)
```

Mapping:

```
1 – 4 px
```

Damit werden **stark gekoppelte Nodes** sichtbar.

---

## 6 Hilfsfunktion: readNodeCouplingMetrics

Diese Funktion liest alle Kopplungsmetriken aus dem Node.

```
readNodeCouplingMetrics(d)
```

Sie aggregiert:

- Calls
- Uses
- Includes
- generische Edges

Ergebnis:

```
{
 inboundCalls
 outboundCalls
 inboundUses
 outboundUses
 inboundIncludes
 outboundIncludes
 inboundEdges
 outboundEdges
 inboundTotal
 outboundTotal
}
```

Diese Struktur wird anschließend für

- Stroke Width
- Ring Width

verwendet.

---

## 7 Rendering im Graph

Der Renderer nutzt die Encoder über:

```
const enc = makeEncoders(nodes)
```

Danach werden die Werte im SVG angewendet.

Beispiele:

Radius:

```
.attr("r", enc.getRadius(d))
```

Stroke Farbe:

```
.style("stroke", enc.getNodeStroke(d))
```

Stroke Breite:

```
.style("stroke-width", enc.getNodeStrokeWidth(d))
```

Funktionsringe:

```
enc.getFunctionRingWidth(d)
```

Der Renderer zeichnet dafür einen zusätzlichen SVG Kreis um den Node.

---

## 8 Designziel

Die Ringe codieren Architekturinformationen ohne zusätzliche UI.

Encoding Schema:

| visuelle Eigenschaft | Bedeutung |
|---|---|
| Node Größe | Cyclomatic Complexity |
| Fill Farbe | Node Typ |
| Randfarbe | API Rolle |
| Randdicke | Coupling |
| Funktionsring | Call Aktivität |

Damit wird der Graph zu einer **Architekturkarte der Anwendung**.

---

## 9 Vorteile des Encoder Designs

- klare Trennung zwischen Daten und Rendering
- konsistente visuelle Sprache
- Erweiterbarkeit für weitere Metriken

Neue Metriken können einfach in

```
render.encoders.js
```

hinzugefügt werden.

Der Renderer muss dafür nicht verändert werden.