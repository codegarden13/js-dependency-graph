# appliste und Appwechsel in app.js

Beim Klick auf eine andere App wird immer:
	•	die neue appId gesetzt
	•	runAnalysis() gestartet
	•	/analyze.js - Route mit genau dieser appId aufgerufen



```js
function handleAppRowSelectionClick(ev, target, listEl) {
  if (isActionClick(ev)) return;

  const row = getClosestAppRow(target);
  if (!row) return;

  const newId = String(row.dataset.appId || "").trim();
  if (!newId) return;

  setSelectedAppId(newId);
  setAppActiveRow(listEl, newId);
  safeRunAnalysis();
}
```

	1.	geklickte Row wird ermittelt
	2.	newId aus data-app-id gelesen
	3.	in #appSelect gespeichert
	4.	UI markiert
	5.	direkt danach safeRunAnalysis() gestartet

Und safeRunAnalysis() ruft einfach das hier auf:
```js
function safeRunAnalysis() {
  runAnalysis().catch((e) => console.error(e));
}
```

runAnalysis() liest dann die aktuelle Auswahl wieder aus dem Hidden Input:

```js
const appId = getSelectedAppIdOrShowStatus();
```

und schickt sie an den Backend-Analyze-Endpoint:

```js
const data = await postAnalyze(appId);
```


also

```js
return fetchJson("/analyze", {
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify({ appId }),
});
```