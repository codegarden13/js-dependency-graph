# Example

#TODO:!More Standard coding Prompts aund mehr Security+ Prompts

wenn ich neu starte, sehe ich den video-Start Icon, - das ist nicht logisch. Logisch wäre ein Button "letztes gerendertes Video anzeigen". Die Videos sind zentral abgelegt, das sollte funktionieren. Setze es um oder unterbreche, falls Dir Informationen fehlen.

# Codezeilen

prüfe wie viele codezeilen ich habe, analysiere ob code duplication existiert. Prüfe ob code effizienter wiederverwendet werden kann oder ob es repititions gibt. Finde heraus , wie viele codezeilen eingespart werden könnten. Der Code soll dabei übersichtlicher und unlesbarer werden, Kommentare sollen nicht angefasst werden, der Code soll nicht unnötig verstreut werden.


# App-Doku
prüfe app, Mach basierend darauf eine Dokumentation über die App nach Doku.md.
Beschreibe zuerst zuerst den Fachlichen, dann den technischen Part.
Im Technischen part will ich auch ein TOC über alle Module sehen.

Mache ein Hauptinhaltsverzeichnis (getrennt für beide Bereiche) und verbinde die Bereiche anschliessend mit sinnvollen Hyperlinks in Markdown.

Nutze die gebräuchlichen Formatierungsoptionen einschliesslich Tabellen die Markdown dafür bietet.

Verwende den Ordner _doku im Workspace für nichts, Verwende den Ordner _doku im Workspace nicht, ignoriere ihn.

# Umsetzung und Varianten
- ziehe das so durch und verwende so weit möglich vorhandene Funktionen. Falls nötig, reduziere dabei die cyclomatic complexity in jeder Datei die du dabei anfasst. 

## Fixes

- fixe es im Code 
 - verwende falls möglich und sinnvoll vorhandene funktionen
 - informiere mich am ende für was Du neue Module anlegen würdest (lege aber keine an). 
 - Mache jede funktion die du anlangst so, dass etwaige cyclomatic Complexity verschwindet.

# Standards


reduce the footprint of the app. Schwerpunkt ist, wiederholte Helfer in nicht zu kleine gemeinsame Utilities zu verschieben und die bestehenden Aufrufer nur minimal umzubauen, damit Verhalten und Lesbarkeit stabil bleiben.
