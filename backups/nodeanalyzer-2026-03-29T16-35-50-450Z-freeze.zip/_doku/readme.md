# Doku Code Architecture Radar

Was du gerade baust ist im Grunde:



Mit noch:
	•	Layer-Bändern
	•	Cluster-Labels
	•	Dominanz
	•	Bundling

wird der Graph dramatisch verständlicher.

## todos

- #TODO:purify.min.js und marked.min.js lokal ablegen
- find Functions with many arguments they indicate either

in d3_codestucture.js:
	•	die Style-Constants ("#fff", "#111", "rgba(...)") zentralisieren, oder
	•	nodeOpacity/nodeDashArray/... als kleine “policy”-Section bündeln, damit CodeScene noch weniger meckert.
----
low cohesion where the function has too many responsibilities, or
a missing abstraction that encapsulates those arguments.

Solution
Start by investigating the responsibilities of the function. Make sure it doesn't do too many things, in which case it should be split into smaller and more cohesive functions.

Consider the refactoring INTRODUCE PARAMETER OBJECT to encapsulate arguments that refer to the same logical concept.


Ähnliche Tools

- SonarQube ist eine Plattform zur statischen Codeanalyse. Sie untersucht Quellcode automatisch und findet Qualitätsprobleme.(Heruntergeladen)
- CodeScene analysiert nicht nur den Code, sondern auch die Entwicklungsgeschichte eines Projekts.
- Sourcegraph ist eine Plattform zum Durchsuchen und Verstehen großer Codebasen. Sie wird oft in großen Organisationen eingesetzt (tausende Repositories).
## Bootstrap
[app.js](../app/public/assets/js/app.js) ist der Bootstrap: 


- Load app presets (/apps) into a compact selectable list (#appList)
- Auto-run analysis when selecting an app
- Define window.onGraphNodeSelected(node) hook used by the D3 graph
- Render README (Requires marked.js + DOMPurify.js) and  selection info panels
- Subscribe to SSE (/events) and mark changed nodes (color + timestamp)

Notes:
- Requires marked.js + DOMPurify.js for README HTML rendering in index  (optional fallback)
- Expects a hidden input: <input type="hidden" id="appSelect" value="">
- Expects: #appList, #status, #graphInfoPanel, #readmePanel, #codeStructureSvg
- Expects D3 renderer global: window.initcodeStructureChart(svgId, metrics) in [d3_codeStructure.js](../app/public/assets/js/d3_codeStructure.js)
- Expects D3 change hook global: window.graphMarkChanged({id, ev, at})
 

- [server.js](../app/server.js) ist zuständig dass die Website gezeichnet werden kann (index.html + JS/CSS assets)


## Ziel für den Graphen

- Function and method extraction
- Complexity heuristics per function

Der Graph soll auf den ersten 2 Sekunden zeigen:

	•	🔵 Welche Files sind zentral?
	•	🟡 Welche Functions sind komplex?
	•	🟣 Welche Functions sind stark genutzt?
	•	🟢 Welche Exports sind API?
	•	🔴 Wo sind Hotspots?


codeGraph/
   ui.tooltip.js          ← DOM tooltip infrastructure
   render.tooltip.js      ← graph tooltip content

## BFS vs DFS

### BFS

BFS = Breadth-First Search (auf Deutsch meist Breitensuche).

Stell dir deinen Code als Graph vor:
	•	Knoten = Dateien / Funktionen
	•	Kanten = import / call / include

BFS bedeutet: Du startest beim Entrypoint und gehst den Graphen schichtweise durch.

Wie BFS arbeitet (Bild im Kopf)

Du hast Ebenen:
	•	Ebene 0: entry.js
	•	Ebene 1: alles, was entry.js importiert
	•	Ebene 2: alles, was diese Imports importieren
	•	usw.

Technisch macht man das mit einer Queue (Warteschlange):
	1.	Entry in die Queue
	2.	Nimm vorn einen Eintrag raus
	3.	Parse die Datei → finde Imports
	4.	Neue (noch nicht besuchte) Dateien hinten in die Queue
	5.	Wiederholen, bis Queue leer

Mini-Beispiel

A importiert B und C
B importiert D
C importiert E

BFS-Reihenfolge:
A → B → C → D → E

(weil erst alle direkten Nachbarn von A, dann deren Nachbarn)

Warum du BFS in deinem Analyzer nutzt
	•	Deterministisch: gleiche Projektstruktur → gleiche Reihenfolge
	•	Schnell “breit” sichtbar: du siehst früh die wichtigsten Top-Level Imports
	•	Gut für Visualisierung: du kannst Ebenen/Depth ableiten (z.B. depth=0/1/2) und das im Layout nutzen

### Unterschied zu DFS (Depth-First Search)

DFS würde “in die Tiefe” gehen:
A → B → D → (zurück) → C → E

BFS ist eher “erst alles auf der gleichen Ebene”.

Wenn du willst, kann ich dir zeigen, wo genau in deiner buildMetricsFromEntrypoint BFS passiert (Queue/visited) und wie du daraus ** zusätzlich node.depth ableitest**, um noch bessere Layouts zu bauen.

## Payload Erzeugung für den Graphen


```txt

Filesystem
     │
     ▼
buildMetricsFromEntrypoint
(Node Backend)
     │
     ▼
metrics JSON
     │
     ▼
Browser
(codegraph renderer)
     │
     ▼
D3 visualization
```


	nach finalizeGraphStats(...) wird der helper attachFunctionChildren(store.nodes) aufgerufen
	

Die Funktion macht:
	•	alle file-Nodes sammeln
	•	alle function-Nodes nach node.file gruppieren
	•	fileNode.children = [...] setzen


### Beispiel file node
```json
{
  "id": "app/config/config.js",
  "kind": "file",
  "lines": 33,
  "complexity": 2,
  "children": [
    {
      "id": "app/config/config.js::getServerConfig@21",
      "kind": "function",
      "lines": 13,
      "complexity": 3
    }
  ]
}
```




```txt
Backend Phase 0: Project Tree Scan (nur Struktur)

  - scanProjectTree(projectRootAbs, maxDepth) emits: dir/file/asset/root nodes + include edges and then filters noise (dotfiles, .DS_Store, node_modules, ...)
        ↓
Backend Phase 1: BFS Parse (code metrics)



async function runAnalysis(projectRoot) in app.js.


  - parseFile() per file
  - emits: imports/use edges, call edges, function nodes (exported/startLine/complexity/lines)
        ↓
Backend Phase 2: Auto Mode (optional enrichment)
  - applyAutoRefs() per parsed file
  - expands referenced dirs/files (bounded) + include edges
        ↓
Backend Phase 3: Finalize (canonical JSON)
  - ensures node.kind + node.group (root/dir/code/doc/data/image)
  - ensures node.type/ext/subtype
  - computes inbound/outbound stats
        ↓
metrics JSON (canonical)
        ↓
Frontend
  - CodeGraphData.normalize(metrics): ONLY validates / adapts shapes
  - d3_codeStructure.js renders purely from JSON (colors from node.group)  in initCodeStructureChart
```
### analyze.js

analyze.js schreibt pro Analyse nur noch Artefakte nach:
	•	/output/code-structure-<runToken>.json
	•	/output/code-structure-<runToken>.csv

Geändert wurde dabei:
	•	metricsByToken komplett entfernt
	•	/metrics-Routen entfernt
	•	JSON-Schreibpfad unter app/public/output ergänzt
	•	zusätzlicher CSV-Export ergänzt
	•	Response von POST /analyze liefert jetzt:
### Unerwünschte Nodes ?

Unerwünschten Nodes treten auf, wenn der erste Scan-Schritt `scanProjectTree` keine versteckten Dateien (Dotfiles) wie `.DS_Store` herausgefiltert hat. Das bedeutet, dass solche Dateien bereits als Nodes im Graphen angelegt wurden. 

Das AutoMode-Modul filtert zwar beim Erweitern von Verzeichnissen und Dateien, kann jedoch keine Nodes entfernen, die zuvor von `scanProjectTree` erzeugt wurden. 

Die Lösung besteht darin, `.DS_Store` und ähnliche Dotfiles bereits in `scanProjectTree` an der Quelle herauszufiltern, was mit der neuen Filterung in `DEFAULT_IGNORE_NAMES` und der `shouldSkipName`-Funktion umgesetzt wurde.

## Final graph
in 📍 app/public/assets/js/d3_codeStructure.js passiert alles Visuelle zb.:

A) Radius der Function-Nodes = Function-Complexity



## nodegraph enhanced

contract codeGraph/ folders

### data.js = Payload → UI-Graph-Daten
ID-Parsing + Contract-Checks
### ui.js = Legend/Filter/State + apply
Alles Filter/Legend/applyFilters nach codeGraph/ui.js
### interactions.js = Drag/Click/Tooltip wiring
Tooltip+Highlight helpers bleiben erstmal in d3_codeStructure.js oder wandern nach interactions.js (wenn du eh dort dran bist)
### hulls.js = Hulls
### d3_codeStructure.js = nur Orchestrator / Render-Pipeline


## Graph automode enhanced


Trenne konsequent:

- kind = strukturelle Kategorie (wenige Werte)
  - root, dir, code, doc, data, asset, image, font … (oder noch weniger)

- type = spezifischer Typ (feingranular, aber kontrolliert)
  - js, ts, css, html, md, json, csv, png, svg, woff2, …


plus: ext, mime, parseHint optional
	•	ext: ".md"
	•	mime: "text/markdown" (optional, oder einfach “group”)
	•	parseHint: "markdown" | "css" | "html" | "json" | null

Warum diese Trennung gut ist:
- kind bleibt stabil fürs Layout/Cluster/Filter (wenige Klassen)
- type/ext gibt dir Präzision für Parser/Renderer



## legende des graphen


### Nodes (Knoten)

Farbe (Fill) = Semantik / Dateityp

Der Knoten bekommt zuerst eine Basisfarbe aus node.group (Backend-Contract):
	•	root: sehr dunkel (Projektwurzel)
	•	dir: blau (Ordner)
	•	code: grau (Code: Dateien + Function-Nodes)
	•	doc: türkis (Markdown/Docs)
	•	data: orange (JSON/CSV/etc.)
	•	image: lila (Bilder)

Falls group fehlt, fällt die UI auf ältere Felder (kind/type) zurück.

Helligkeit / Ton (bei Functions) = Komplexität

Für Function-Nodes wird die Farbe zusätzlich “getönt”:
	•	heller = eher simple Funktion
	•	dunkler = komplexer (höhere cyclomatic complexity / heuristische complexity)

Für Nicht-Functions bleibt es meist bei der Basisfarbe (ggf. minimal getönt, wenn ein _complexityScore existiert).

⸻

Größe (Radius) = Lines-Score / “Größenindikator”

Der Kreisradius kommt aus:
	•	radius = 6..26 basierend auf d._lineScore

Interpretation:
	•	größer = “mehr Gewicht” (typisch: mehr Lines / größerer Anteil im Graph)
	•	kleiner = kurze/kleine Units

Wichtig: Das ist kein direktes “LOC”-Mapping, sondern ein normalisierter Score (_lineScore).

Der Durchmesser (bzw. Radius) deiner Function-Nodes wird im Renderer public/assets/js/d3_codeStructure.js über getRadius(d) bestimmt.

Wenn _lineScore klein ist, ist der Node klein. Wenn _lineScore bei vielen ähnlich ist, wirken sie gleich groß.

1) Die unmittelbare Formel

Im Code steht sinngemäß:
	•	getRadius(d) nutzt d._lineScore
	•	und rechnet daraus einen Radius zwischen minR und maxR

Typisch so (aus deinem Renderer):
	•	minR = 6
	•	maxR = 26
	•	radius = minR + (maxR - minR) * d._lineScore

➡️ Durchmesser = 2 × Radius

2) Woher kommt _lineScore?

_lineScore wird vor dem Rendern in CodeGraphData.normalize(metrics) (dein data.js) aus node.lines berechnet.

Es gilt bei Function-Nodes:
	•	node.lines ≈ fn.locLines (also “Zeilenumfang der Funktion”)

Dann macht normalize eine Normalisierung (bei dir log-skaliert), etwa:
	•	viele kleine Functions → kleine Scores
	•	wenige große Functions → größere Scores

Und daraus wird _lineScore ∈ [0..1].


⸻

Outline / Stroke (Rand) = Status
	•	rot (starker Rand): d._changed === true → “zuletzt geändert” (Live-Change Marker)
	•	kräftiger Rand bei exported Function: exported === true → Export/öffentlich
	•	sonst: sehr dünner, transparenter Standardrand

⸻

#### Ring um Functions (2. Kreis) = Usage / Consumption

Bei Function-Nodes wird ein zusätzlicher Ring gezeichnet:

Ringdicke = _inCalls
	•	strokeWidth = clamp(_inCalls, 1..12)
	•	_inCalls = 0 → kein Ring

Interpretation:
	•	dicker Ring = Funktion wird oft aufgerufen (viele inbound call edges)
	•	kein Ring = keine erkannten Aufrufer (kann echt “unused” sein oder Parser-Limit)

Ringfarbe
	•	exported Function → Export-Highlight-Farbe
	•	sonst: neutral (grau/transluzent)

⸻

### Pfeile / Kanten (Links)

Richtung
	•	source → target
	•	Bei den meisten Kanten gibt es ein Arrowhead.
	•	Ausnahme: include-Edges haben kein Arrowhead (bewusst “strukturell”, nicht “Flow”).

Kantenarten (typisch, aus Backend)
	•	include: Datei/Ordner enthält Datei/Funktion (struktureller Zusammenhang)
	•	use: nutzt/abhängig (z.B. Import, Referenz, Binding)
	•	call: Funktionsaufruf
	•	extends: Vererbung/Erweiterung
	•	default: Rest

In deinem Renderer bekommen Links CSS-Klassen link include|use|call|extends, d.h. ihre genaue Farbe hängt meistens an CSS (nicht hart im JS), aber semantisch ist es so gedacht.


### Das !-Badge (Unused)

Das Ausrufezeichen markiert Nodes mit:
	•	d._unused === true

Interpretation im Kontext “unused nur für functions”:
	•	Function ist “unbenutzt”, wenn der Analyzer keine inbound calls/uses finden konnte (typisch _inCalls === 0 und/oder _inUses === 0 je nach Definition im Backend).

Wichtig: Das ! ist nur so gut wie die Call/Use-Erkennung.
Wenn du z.B. api.renderOptions() hast und die Member-Calls nicht korrekt auf die Property attribuiert wurden, kann etwas falsch positiv als unused auftauchen.

## Quick-Read des Graphen

Wenn du “auf einen Blick” interpretieren willst:
	•	Große graue Kreise = große Code-Units (Dateien oder große Functions)
	•	Dunklere Function-Nodes = komplexere Funktionen
	•	Dicker Ring = häufig aufgerufen → “Hot path”
	•	! = vom Analyzer als unbenutzt markiert → Kandidat für Cleanup / falsches Positive prüfen
	•	Viele violett/blauartige Link-Cluster = starke Abhängigkeitsbereiche (Module/Subsysteme)

Wenn du willst, kann ich dir daraus auch eine UI-Legende direkt im Panel bauen (kleines HTML mit Farbchips + Ringdemo), damit Nutzer das im Tool selbst sehen.

### was bestimmt den durchmesser der function node


3) Warum sind Functions manchmal trotzdem ähnlich groß?

Weil die Skala log-normalisiert ist. Wenn die meisten Functions LOC z.B. zwischen 1 und 8 liegen, dann liegt _lineScore für viele sehr nah zusammen → ähnliche Radien.

⸻

Wie du es datengetrieben steuern kannst (ohne Hardcode)

Du hast 3 Stellschrauben, die richtig “wirken”:

A) Skalierung ändern (statt log → sqrt/linear)

In normalize:
	•	linear: Unterschiede sehr hart
	•	sqrt: guter Mittelweg
	•	log: glättet stark (was du gerade siehst)

B) minR/maxR per zentraler Config

Du hattest ja schon “Auto Defaults zentral”. Genau dafür:
	•	minR, maxR, radiusPadding, linkDistance
	•	als window.CODEGRAPH_CONFIG = {...}

C) Function-spezifische Radius-Policy

Du kannst z.B. sagen:
	•	file-nodes: radius aus file lines
	•	function-nodes: radius aus locLines, aber mit eigener Range (z.B. 4..18)
	•	exported functions: +2 Bonus

Das macht Function-Nodes sofort “aussagekräftiger”.

### Debugs

Debug: Welche Werte bestimmen gerade den Radius?

In DevTools:

```js
const n = window.lastGraphState.nodes.find(x => x.kind==="function");
({ id:n.id, lines:n.lines, _lineScore:n._lineScore })
```

### ebventuell

Wenn du willst, sag kurz:
	•	willst du mehr Spreizung bei Functions (optisch deutlicher)?
Dann stelle ich dir die beste Default-Formel ein (meist sqrt + eigenes min/max nur für functions).