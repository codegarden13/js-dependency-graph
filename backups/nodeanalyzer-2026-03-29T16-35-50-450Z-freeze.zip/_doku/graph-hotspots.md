# Force directed Graph Hotspots – NodeAnalyzer

Diese Datei beschreibt die aktuelle Hotspot-Logik des NodeAnalyzer.

Sie erklärt:

- was ein Hotspot ist
- wie der Score berechnet wird
- was Badge-Inhalt und Badge-Rang bedeuten
- wie Farbe und Farbtonabstufungen entstehen
- wo die Gewichtung zwischen CC und Rang gesteuert wird
- wie die Daten in JSON, CSV und WebGUI verwendet werden

---

## 1. Grundidee

Ein Hotspot ist Code, der zwei Eigenschaften gleichzeitig hat:

1. Er wird häufig geändert.
2. Er ist teuer zu verstehen oder zu warten.

Der NodeAnalyzer verwendet dafür eine **CodeScene-ähnliche Heuristik**.

Dabei zählen nicht nur rohe Cyclomatic Complexity-Werte. Zusätzlich fließen ein:

- Dateigröße (`LOC` / `lines`)
- Änderungshäufigkeit aus Git

Ein Hotspot ist damit weder nur ein Komplexitätswert noch nur ein Git-Wert. Er ist die Kombination aus:

```text
Änderungshäufigkeit × kognitive Last
```

---

## 2. Welche Nodes Hotspot-Daten bekommen

Die Hotspot-Berechnung startet auf **File-Nodes**.

Warum auf Dateien?

- Git-Historie ist dateibasiert.
- Commits referenzieren Dateien, nicht einzelne Funktionen.
- Dadurch kann `change frequency` direkt pro Datei bestimmt werden.

Danach werden die Hotspot-Werte auf Function-Nodes vererbt:

- `_changeFreq`
- `_lastTouchedAt`
- `_hotspotScore`
- `_hotspotRank`
- `hotspot`

Das bedeutet:

- die eigentliche Berechnung geschieht für Dateien
- die Darstellung kann Datei- und Funktions-Nodes gleichermaßen hervorheben

---

## 3. Wo die Change Frequency herkommt

Die Änderungshäufigkeit wird aus Git gelesen.

Verwendeter Git-Befehl:

```bash
git log --name-only --format=@@@%ct --no-merges -- .
```

Bedeutung:

- `git log` liest die Commit-Historie
- `--name-only` listet die in jedem Commit geänderten Dateien
- `--format=@@@%ct` schreibt pro Commit einen Marker mit Unix-Timestamp
- `--no-merges` ignoriert Merge-Commits
- `-- .` begrenzt die Analyse auf das aktuelle Projekt

Die Ausgabe wird zeilenweise geparst.

Für jede Datei gilt:

```text
change frequency = Anzahl der Commits,
in denen die Datei vorkommt
```

Wichtig:

- es geht **nicht** um die Anzahl geänderter Zeilen
- es geht **nicht** um die Diff-Größe
- es geht nur darum, **wie oft** die Datei in der Historie berührt wurde

---

## 4. Welche Rohdaten pro Datei verwendet werden

Für jede Datei werden diese Werte gelesen.

### 4.1 Complexity

Aus dem Graph-Metrics-JSON:

```text
node.complexity
```

Das ist die statische Komplexität der Datei.

### 4.2 Lines

Aus dem Graph-Metrics-JSON:

```text
node.lines
```

Das ist die Dateigröße in Zeilen.

### 4.3 Change Frequency

Aus Git:

```text
gitStat.commits
```

Das ist die Anzahl der Commits, in denen die Datei geändert wurde.

### 4.4 Last Touched Timestamp

Ebenfalls aus Git:

```text
gitStat.lastTouchedEpoch
```

Dieser Wert wird in ISO-Zeit umgewandelt und als `_lastTouchedAt` gespeichert.

---

## 5. Normalisierung

Die Rohwerte haben sehr unterschiedliche Größenordnungen.

Beispiel:

- Complexity: vielleicht 3 bis 200
- Lines: vielleicht 20 bis 2000
- Commits: vielleicht 1 bis 400

Damit diese Werte sinnvoll kombinierbar werden, normalisiert der NodeAnalyzer sie auf einen Bereich von:

```text
0 .. 1
```

Dafür wird eine **logarithmische Skalierung** verwendet:

```text
normalized = log(1 + value) / log(1 + maxValue)
```

Vereinfacht bedeutet das:

- kleine Unterschiede im unteren Bereich bleiben sichtbar
- extreme Ausreißer dominieren nicht alles
- die Verteilung wird stabiler

Das geschieht für:

- Complexity
- Lines
- Change Frequency

---

## 6. Berechnung der kognitiven Last

Der NodeAnalyzer baut zuerst eine Annäherung an die „Versteh-Kosten“ des Codes.

Interner Name:

```text
codeHealthPressure01
```

Formel:

```text
codeHealthPressure01 =
  0.8 × normalizedComplexity
+ 0.2 × normalizedLines
```

Bedeutung:

- Complexity zählt stärker als bloße Größe
- große Dateien erhöhen den Druck zusätzlich
- eine sehr große, aber simple Datei steigt weniger stark
- eine komplexe Datei steigt deutlich stärker

Warum 80/20?

- Complexity ist der stärkere Indikator für mentale Last
- LOC ist wichtig, aber eher unterstützend
- das ist eine pragmatische Heuristik, keine mathematische Naturkonstante

---

## 7. Berechnung des Hotspot-Scores

Danach wird die Änderungshäufigkeit mit der kognitiven Last kombiniert.

Formel:

```text
hotspotScore = normalizedChangeFrequency × codeHealthPressure01
```

Ausgeschrieben:

```text
hotspotScore =
  normalizedChangeFrequency ×
  (0.8 × normalizedComplexity + 0.2 × normalizedLines)
```

Interpretation:

Ein hoher Hotspot-Score entsteht nur dann, wenn **beide Seiten hoch sind**:

- die Datei wird oft geändert
- die Datei ist teuer zu verstehen

Beispiele:

### Fall A – häufig geändert, aber simpel

- viele Commits
- niedrige Complexity
- kleine Datei

→ mittlerer oder niedriger Hotspot

### Fall B – sehr komplex, aber fast nie geändert

- wenige Commits
- hohe Complexity
- große Datei

→ ebenfalls kein Top-Hotspot

### Fall C – häufig geändert und komplex

- viele Commits
- hohe Complexity
- große Datei

→ hoher Hotspot

Das ist die gewünschte Aussage:

> Kritisch ist nicht nur komplizierter Code.  
> Kritisch ist komplizierter Code, den man ständig anfassen muss.

---

## 8. Ranking

Nachdem der Score für alle File-Nodes berechnet wurde, werden diese absteigend sortiert.

Sortierung:

1. höherer `_hotspotScore` zuerst
2. bei Gleichstand Sortierung nach `id`

Danach erhält jede Datei:

```text
_hotspotRank = 1, 2, 3, ...
```

Zusätzlich wird ein boolesches Feld gesetzt:

```text
hotspot = true | false
```

Aktuelle Regel:

- `hotspot = true`, wenn der Node in den **Top 10** liegt
- und `_hotspotScore > 0`

---

## 9. Badge: Was genau angezeigt wird

Das Badge zeigt eine kompakte Kombination aus:

```text
Rang · CC-Wert
```

Beispiele:

- `1 · CC24`
- `2 · CC57`
- `5 · CC11`

Bedeutung:

- der erste Teil ist der **Hotspot-Rang**
- der zweite Teil ist die **Cyclomatic Complexity** des Nodes

Wichtig:

- der Rang sagt, wie weit oben der Hotspot im Vergleich zu anderen Hotspots steht
- der CC-Wert sagt, wie komplex dieser konkrete Node ist
- der numerische Hotspot-Score steckt weiterhin separat in `_hotspotScore`

Das Badge wird nur für die **Top 5 Hotspots** angezeigt.

---

## 10. Wie Farbe und Farbtonabstufungen entstehen

Die Hotspot-Darstellung verwendet nicht mehr nur eine starre Magenta-Farbe.

Stattdessen wird pro Hotspot eine **Farbintensität** berechnet.

Ziel:

- der visuell stärkste Kandidat soll sofort sichtbar sein
- besonders relevant sind Nodes mit Rang `1` und hoher CC
- Richtung Rang `5` und/oder kleinerer CC soll die Farbe sichtbar verblassen

### 10.1 Emphasis-Score

Im Repaint-Modul wird dafür ein zusätzlicher Wert gebildet:

```text
hotspotEmphasis01
```

Dieser Wert liegt zwischen:

```text
0 .. 1
```

Bedeutung:

- `1` = maximale visuelle Betonung
- `0` = minimale visuelle Betonung innerhalb der Hotspot-Skala

### 10.2 Einfluss des Rangs

Der Rang wird auf eine Skala von 0 bis 1 abgebildet.

Dabei gilt:

- Rang `1` = stärkster Rangbeitrag
- Rang `5` = schwächster Rangbeitrag innerhalb der Top-Hotspot-Zone

Formal:

```text
rank01 = 1 - ((min(rank, 5) - 1) / 4)
```

Das ergibt ungefähr:

- Rank 1 → 1.00
- Rank 2 → 0.75
- Rank 3 → 0.50
- Rank 4 → 0.25
- Rank 5 → 0.00

### 10.3 Einfluss der CC

Auch die Cyclomatic Complexity wird auf `0 .. 1` normiert.

Dafür wird wieder logarithmisch skaliert:

```text
cc01 = log(1 + cc) / log(1 + 120)
```

Bedeutung:

- höhere CC erhöht die visuelle Betonung
- extreme Ausreißer werden abgefedert
- Unterschiede im mittleren Bereich bleiben sichtbar

### 10.4 Gewichtung zwischen Rang und CC

Die endgültige Farbbetonung wird aktuell so gemischt:

```text
hotspotEmphasis01 =
  0.6 × rank01
+ 0.4 × cc01
```

Das ist die **entscheidende Stelle**, an der die Gewichtung geregelt wird.

### 10.5 Wo wird diese Gewichtung gesteuert?

In:

```text
app/public/assets/js/codeGraph/render.repaint.js
```

konkret in der Funktion:

```js
function hotspotEmphasis01(d) {
  const rank = readHotspotRank(d);
  const cc = readHotspotCc(d);

  const rank01 = (rank == null)
    ? 0
    : clamp01(1 - ((Math.min(rank, 5) - 1) / 4));

  const cc01 = clamp01(Math.log1p(cc) / Math.log1p(120));

  return clamp01((rank01 * 0.6) + (cc01 * 0.4));
}
```

Wenn du die Gewichtung ändern willst, dann genau hier.

Beispiele:

- **mehr Fokus auf Rang:** `0.7 × rank01 + 0.3 × cc01`
- **mehr Fokus auf CC:** `0.4 × rank01 + 0.6 × cc01`

---

## 11. Wie aus dem Emphasis-Score echte Farben werden

Nachdem `hotspotEmphasis01` berechnet wurde, werden Farben zwischen einer **schwachen** und einer **starken** Farbe interpoliert.

### 11.1 Fill-Farbe

Für den Node-Fill gilt aktuell:

- starke Farbe: `#ff1493`
- schwache Farbe: `#ffd6eb`

Das heißt:

- hohe Betonung → kräftiges Magenta
- niedrige Betonung → helles Rosa

Konzeptuell:

```text
fillColor = mix(weakPink, strongMagenta, hotspotEmphasis01)
```

### 11.2 Outline / Halo

Für Outline und Halo gilt aktuell:

- starke Farbe: `#f0ffff`
- schwache Farbe: `#f7fbff`

Das heißt:

- starke Hotspots bekommen eine sichtbare, kühl helle Kontur
- schwächere Hotspots erhalten eine viel blassere Kontur

### 11.3 Wo passiert das?

Ebenfalls in:

```text
app/public/assets/js/codeGraph/render.repaint.js
```

über diese Funktionen:

```js
function hotspotFillColor(d) {
  const strong = "#ff1493";
  const weak = "#ffd6eb";
  return mixHex(weak, strong, hotspotEmphasis01(d));
}

function hotspotOutlineColor(d) {
  const strong = "#f0ffff";
  const weak = "#f7fbff";
  return mixHex(weak, strong, hotspotEmphasis01(d));
}
```

---

## 12. Wo die Hotspot-Farben im Graph angewendet werden

Die dynamischen Farben werden im Repaint-Layer auf mehrere Elemente angewendet:

- Node-Fill
- Node-Stroke
- Halo
- Label-Farbe
- Badge-Hintergrund

Das passiert ebenfalls in:

```text
app/public/assets/js/codeGraph/render.repaint.js
```

Typische Stellen sind:

- `nodeFill(d, enc)`
- `nodeStroke(d, enc)`
- `repaintHotspotHalos(...)`
- `repaintNodeBodies(...)`
- `repaintLabels(...)`

Das CSS ist dabei absichtlich entschärft, damit diese dynamischen Farben nicht wieder überschrieben werden.

---

## 13. Welche Felder im JSON entstehen

Für File-Nodes:

- `_changeFreq`
- `_lastTouchedAt`
- `_hotspotScore`
- `_hotspotRank`
- `hotspot`

Für Function-Nodes:

- dieselben Felder, vom Owner-File geerbt

Beispiel:

```json
{
  "id": "app/lib/parseAst.js",
  "kind": "file",
  "complexity": 172,
  "lines": 619,
  "_changeFreq": 47,
  "_lastTouchedAt": "2026-02-11T09:14:22.000Z",
  "_hotspotScore": 0.83,
  "_hotspotRank": 1,
  "hotspot": true
}
```

---

## 14. Welche Felder im CSV entstehen

Im CSV werden die Hotspot-Daten ebenfalls ausgegeben.

Relevante Spalten:

- `changeFreq`
- `lastTouchedAt`
- `hotspotScore`
- `hotspotRank`
- `hotspot`

Beispiel:

```csv
relation,kind,id,lines,complexity,changeFreq,hotspotScore,hotspotRank,hotspot
node,file,app/lib/parseAst.js,619,172,47,0.83,1,true
```

---

## 15. Wie Hotspots in der WebGUI dargestellt werden

Hotspots werden visuell kodiert über:

- **Node-Farbe**
- **Halo / Outline**
- **Badge**

### 15.1 Node-Farbe

Die Füllfarbe kommt aus der dynamischen Hotspot-Skala.

Stärkste Nodes:

- sehr kräftiges Magenta

Schwächere Nodes:

- helleres Rosa

### 15.2 Halo / Outline

Zusätzlich wird ein Halo um den Node gelegt.

Auch dieser verblasst mit sinkender Betonung.

### 15.3 Badge

Die Top 5 Hotspots bekommen zusätzlich ein Badge mit:

```text
Rang · CC
```

Beispiel:

- `1 · CC24`
- `2 · CC57`
- `3 · CC18`

Die visuelle Steuerung liegt verteilt auf:

- `app/public/assets/js/codeGraph/render.repaint.js`
- `app/public/assets/css/graph.css`

---

## 16. Was diese Heuristik gut erkennt

Die Metrik ist gut darin, folgende Kandidaten sichtbar zu machen:

- instabile Kernmodule
- komplexe Utility-Dateien mit vielen Änderungen
- Parser / Resolver / zentrale Infrastruktur-Dateien
- Bereiche mit hoher Wartungslast

Die Metrik hilft also besonders bei:

- Refactoring-Priorisierung
- Risikoabschätzung
- Architektur-Reviews

---

## 17. Grenzen der Heuristik

Die aktuelle Hotspot-Metrik ist bewusst pragmatisch.

Sie hat Grenzen:

### 17.1 Dateibasiert, nicht funktionsbasiert

Git liefert Änderungen auf Dateiebene.

Darum ist die Change Frequency nicht direkt pro Funktion messbar.

### 17.2 Keine Diff-Größe

Ein Commit zählt gleich, egal ob:

- 1 Zeile geändert wurde
- 300 Zeilen geändert wurden

### 17.3 Kein Zeitfenster

Aktuell wird die komplette Git-Historie verwendet.

Das bedeutet:

- alte historische Aktivität zählt weiter mit
- ein Modul kann historisch stark gewesen sein, aktuell aber ruhig

### 17.4 Keine semantische Qualität

Die Metrik kennt nicht:

- Bugfix vs. Feature
- riskante vs. harmlose Änderungen
- Testcode vs. Produktionscode

---

## 18. Mögliche Weiterentwicklungen

Für eine noch stärkere CodeScene-Nähe wären diese Erweiterungen sinnvoll:

### 18.1 Zeitfenster

Beispiel:

- letzte 3 Monate
- letzte 6 Monate
- letzte 12 Monate

Dann wird die Metrik aktueller.

### 18.2 Churn statt nur Commit Count

Nicht nur zählen, **wie oft** eine Datei vorkam, sondern auch:

- wie viele Zeilen hinzugefügt wurden
- wie viele Zeilen entfernt wurden

### 18.3 Funktions-Hotspots

Mit Blame- oder feineren Diff-Daten könnte man Hotspots näher an einzelne Funktionen bringen.

### 18.4 Zusätzliche kognitive Last

Erweiterungen wie:

- Nesting / Verschachtelung
- Fan-in / Fan-out
- Import-Zentralität
- Instabilität

würden den Score weiter verfeinern.

---

## 19. Kurzfassung

Der NodeAnalyzer verwendet aktuell diese Logik:

```text
1. Git-Historie lesen
2. pro Datei Commits zählen
3. Complexity und LOC normalisieren
4. kognitive Last berechnen
5. mit Change Frequency multiplizieren
6. Score ranken
7. Rang und CC zu einem Emphasis-Wert mischen
8. daraus Fill- und Outline-Farben interpolieren
9. Top-Hotspots farblich markieren
10. Top 5 mit Badge „Rang · CC" versehen
```

Die visuelle Gewichtung wird aktuell hier geregelt:

```text
0.6 × Rang + 0.4 × CC
```

Diese Mischung bestimmt, wie kräftig oder blass ein Hotspot im Graph erscheint.

---

## Ende

Diese Datei dokumentiert den aktuellen Hotspot-Algorithmus und die visuelle Hotspot-Skala des NodeAnalyzer.# Graph Hotspots – NodeAnalyzer

Diese Datei dokumentiert die aktuelle Hotspot-Logik des NodeAnalyzer.

Sie erklärt:

- was ein Hotspot ist
- wie der Score berechnet wird
- was Badge-Inhalt und Badge-Rang bedeuten
- wie Farbe und Farbtonabstufungen entstehen
- wo die Gewichtung zwischen CC und Rang gesteuert wird
- wie die Daten in JSON, CSV und WebGUI verwendet werden

---

# 1. Grundidee

Ein Hotspot ist Code, der zwei Eigenschaften gleichzeitig hat:

1. **Er wird häufig geändert**
2. **Er ist teuer zu verstehen oder zu warten**

Der NodeAnalyzer verwendet dafür eine **CodeScene-ähnliche Heuristik**.

Das bedeutet:

- nicht nur rohe Cyclomatic Complexity zählt
- auch Dateigröße (LOC / lines) fließt ein
- zusätzlich wird die Änderungshäufigkeit aus Git berücksichtigt

Der Hotspot ist also kein reiner Komplexitätswert und auch kein reiner Git-Wert.

Er ist die Kombination aus:

```text
Änderungshäufigkeit × kognitive Last
```

---

# 2. Welche Nodes Hotspot-Daten bekommen

Die Hotspot-Berechnung startet auf **File-Nodes**.

Warum File-Nodes?

- Git-Historie ist dateibasiert
- Commits referenzieren Dateien, nicht einzelne Funktionen
- dadurch kann Change Frequency direkt pro Datei bestimmt werden

Danach werden die Hotspot-Werte auf Function-Nodes vererbt:

- eine Funktion bekommt den Hotspot ihres Owner-Files
- ebenso `_changeFreq`, `_lastTouchedAt`, `_hotspotScore`, `_hotspotRank`

Das bedeutet:

- die **eigentliche Berechnung** geschieht für Dateien
- die **Darstellung** kann Datei- und Funktions-Nodes gleichermaßen hervorheben

---

# 3. Wo die Change Frequency herkommt

Die Änderungshäufigkeit wird aus Git gelesen.

Verwendeter Git-Befehl:

```bash
git log --name-only --format=@@@%ct --no-merges -- .
```

Bedeutung:

- `git log` liest die Commit-Historie
- `--name-only` listet die in jedem Commit geänderten Dateien
- `--format=@@@%ct` schreibt pro Commit einen Marker mit Unix-Timestamp
- `--no-merges` ignoriert Merge-Commits
- `-- .` begrenzt die Analyse auf das aktuelle Projekt

Die Ausgabe wird zeilenweise geparst.

Für jede Datei gilt:

```text
change frequency = Anzahl der Commits,
in denen die Datei vorkommt
```

Wichtig:

- es geht **nicht** um Anzahl geänderter Zeilen
- es geht **nicht** um Diff-Größe
- es geht nur darum, **wie oft die Datei in der Historie berührt wurde**

---

# 4. Welche Rohdaten pro Datei verwendet werden

Für jede Datei werden diese Werte gelesen:

## 4.1 Complexity

Aus dem Graph-Metrics-JSON:

```text
node.complexity
```

Das ist die statische Komplexität der Datei.

## 4.2 Lines

Aus dem Graph-Metrics-JSON:

```text
node.lines
```

Das ist die Dateigröße in Zeilen.

## 4.3 Change Frequency

Aus Git:

```text
gitStat.commits
```

Das ist die Anzahl der Commits, in denen die Datei geändert wurde.

## 4.4 Last Touched Timestamp

Ebenfalls aus Git:

```text
gitStat.lastTouchedEpoch
```

Dieser Wert wird in ISO-Zeit umgewandelt und als `_lastTouchedAt` gespeichert.

---

# 5. Normalisierung

Die Rohwerte haben sehr unterschiedliche Größenordnungen.

Beispiel:

- Complexity: vielleicht 3 bis 200
- Lines: vielleicht 20 bis 2000
- Commits: vielleicht 1 bis 400

Damit diese Werte sinnvoll kombinierbar werden, normalisiert der NodeAnalyzer sie in einen Bereich von:

```text
0 .. 1
```

Dafür wird eine **logarithmische Skalierung** verwendet:

```text
normalized = log(1 + value) / log(1 + maxValue)
```

Vereinfacht bedeutet das:

- kleine Unterschiede im unteren Bereich bleiben sichtbar
- extreme Ausreißer dominieren nicht alles
- die Verteilung wird stabiler

Das geschieht für:

- Complexity
- Lines
- Change Frequency

---

# 6. Berechnung der kognitiven Last

Der NodeAnalyzer baut zuerst eine Annäherung an die "Versteh-Kosten" des Codes.

Interner Name:

```text
codeHealthPressure01
```

Formel:

```text
codeHealthPressure01 =
  0.8 × normalizedComplexity
+ 0.2 × normalizedLines
```

Bedeutung:

- Complexity zählt stärker als bloße Größe
- große Dateien erhöhen den Druck zusätzlich
- eine sehr große, aber simple Datei steigt weniger stark
- eine komplexe Datei steigt deutlich stärker

Warum 80/20?

- Complexity ist der stärkere Indikator für mentale Last
- LOC ist wichtig, aber eher unterstützend
- das ist eine pragmatische Heuristik, keine mathematische Naturkonstante

---

# 7. Berechnung des Hotspot-Scores

Danach wird die Änderungshäufigkeit mit der kognitiven Last kombiniert.

Formel:

```text
hotspotScore = normalizedChangeFrequency × codeHealthPressure01
```

Ausgeschrieben:

```text
hotspotScore =
  normalizedChangeFrequency ×
  (0.8 × normalizedComplexity + 0.2 × normalizedLines)
```

Interpretation:

Ein hoher Hotspot-Score entsteht nur dann, wenn **beide Seiten hoch sind**:

- Datei wird oft geändert
- Datei ist teuer zu verstehen

Beispiele:

## Fall A – häufig geändert, aber simpel

- viele Commits
- niedrige Complexity
- kleine Datei

→ mittlerer oder niedriger Hotspot

## Fall B – sehr komplex, aber fast nie geändert

- wenige Commits
- hohe Complexity
- große Datei

→ ebenfalls kein Top-Hotspot

## Fall C – häufig geändert und komplex

- viele Commits
- hohe Complexity
- große Datei

→ hoher Hotspot

Das ist genau die gewünschte Aussage:

> Kritisch ist nicht nur komplizierter Code.  
> Kritisch ist komplizierter Code, den man ständig anfassen muss.

---

# 8. Ranking

Nachdem der Score für alle File-Nodes berechnet wurde, werden diese absteigend sortiert.

Sortierung:

1. höherer `_hotspotScore` zuerst
2. bei Gleichstand Sortierung nach `id`

Danach erhält jede Datei:

```text
_hotspotRank = 1, 2, 3, ...
```

Zusätzlich wird ein boolesches Feld gesetzt:

```text
hotspot = true | false
```

Aktuelle Regel:

- `hotspot = true`, wenn der Node in den **Top 10** liegt
- und `_hotspotScore > 0`

---

# 9. Badge: Was genau angezeigt wird

Das Badge zeigt heute **nicht nur den Rang**, sondern eine kompakte Kombination aus:

```text
Rang · CC-Wert
```

Beispiele:

- `1 · CC24`
- `2 · CC57`
- `5 · CC11`

Bedeutung:

- der erste Teil ist der **Hotspot-Rang**
- der zweite Teil ist die **Cyclomatic Complexity** des Nodes

Wichtig:

- der Rang sagt, **wie weit oben der Hotspot im Vergleich zu anderen Hotspots steht**
- der CC-Wert sagt, **wie komplex dieser konkrete Node ist**
- der numerische Hotspot-Score steckt weiterhin separat in `_hotspotScore`

Das Badge wird nur für die **Top 5 Hotspots** angezeigt.

---

# 10. Wie Farbe und Farbtonabstufungen entstehen

Die Hotspot-Darstellung verwendet nicht mehr nur eine starre Magenta-Farbe.

Stattdessen wird pro Hotspot eine **Farbintensität** berechnet.

Ziel:

- der visuell stärkste Kandidat soll sofort sichtbar sein
- besonders relevant sind Nodes mit:
  - **Rang 1**
  - **hoher CC**
- Richtung **Rang 5** und/oder kleinerer CC soll die Farbe sichtbar verblassen

## 10.1 Emphasis-Score

Im Repaint-Modul wird dafür ein zusätzlicher Wert gebildet:

```text
hotspotEmphasis01
```

Dieser Wert liegt zwischen:

```text
0 .. 1
```

Bedeutung:

- `1` = maximale visuelle Betonung
- `0` = minimale visuelle Betonung innerhalb der Hotspot-Skala

## 10.2 Einfluss des Rangs

Der Rang wird auf eine Skala von 0 bis 1 abgebildet.

Dabei gilt:

- Rang `1` = stärkster Rangbeitrag
- Rang `5` = schwächster Rangbeitrag innerhalb der Badge-/Top-Hotspot-Zone

Formal:

```text
rank01 = 1 - ((min(rank, 5) - 1) / 4)
```

Das ergibt ungefähr:

- Rank 1 → 1.00
- Rank 2 → 0.75
- Rank 3 → 0.50
- Rank 4 → 0.25
- Rank 5 → 0.00

## 10.3 Einfluss der CC

Auch die Cyclomatic Complexity wird auf 0..1 normiert.

Dafür wird wieder logarithmisch skaliert:

```text
cc01 = log(1 + cc) / log(1 + 120)
```

Bedeutung:

- höhere CC erhöht die visuelle Betonung
- extreme Ausreißer werden abgefedert
- Unterschiede im mittleren Bereich bleiben sichtbar

## 10.4 Gewichtung zwischen Rang und CC

Die endgültige Farbbetonung wird aktuell so gemischt:

```text
hotspotEmphasis01 =
  0.6 × rank01
+ 0.4 × cc01
```

Das ist die **entscheidende Stelle**, an der die Gewichtung geregelt wird.

### Wo wird diese Gewichtung gesteuert?

In:

```text
app/public/assets/js/codeGraph/render.repaint.js
```

konkret in der Funktion:

```js
function hotspotEmphasis01(d) {
  const rank = readHotspotRank(d);
  const cc = readHotspotCc(d);

  const rank01 = (rank == null)
    ? 0
    : clamp01(1 - ((Math.min(rank, 5) - 1) / 4));

  const cc01 = clamp01(Math.log1p(cc) / Math.log1p(120));

  return clamp01((rank01 * 0.6) + (cc01 * 0.4));
}
```

Wenn du die Gewichtung ändern willst, dann genau hier.

Beispiele:

- **mehr Fokus auf Rang:** `0.7 × rank01 + 0.3 × cc01`
- **mehr Fokus auf CC:** `0.4 × rank01 + 0.6 × cc01`

---

# 11. Wie aus dem Emphasis-Score echte Farben werden

Nachdem `hotspotEmphasis01` berechnet wurde, werden Farben zwischen einer **schwachen** und einer **starken** Farbe interpoliert.

## 11.1 Fill-Farbe

Für den Node-Fill gilt aktuell:

- starke Farbe: `#ff1493`
- schwache Farbe: `#ffd6eb`

Das heißt:

- hohe Betonung → kräftiges Magenta
- niedrige Betonung → helles Rosa

Konzeptuell:

```text
fillColor = mix(weakPink, strongMagenta, hotspotEmphasis01)
```

## 11.2 Outline / Halo

Für Outline und Halo gilt aktuell:

- starke Farbe: `#f0ffff`
- schwache Farbe: `#f7fbff`

Das heißt:

- starke Hotspots bekommen eine sichtbare, kühl helle Kontur
- schwächere Hotspots erhalten eine viel blassere Kontur

## 11.3 Wo passiert das?

Ebenfalls in:

```text
app/public/assets/js/codeGraph/render.repaint.js
```

über diese Funktionen:

```js
function hotspotFillColor(d) {
  const strong = "#ff1493";
  const weak = "#ffd6eb";
  return mixHex(weak, strong, hotspotEmphasis01(d));
}

function hotspotOutlineColor(d) {
  const strong = "#f0ffff";
  const weak = "#f7fbff";
  return mixHex(weak, strong, hotspotEmphasis01(d));
}
```

---

# 12. Wo die Hotspot-Farben im Graph angewendet werden

Die dynamischen Farben werden im Repaint-Layer auf mehrere Elemente angewendet:

- Node-Fill
- Node-Stroke
- Halo
- Label-Farbe
- Badge-Hintergrund

Das passiert ebenfalls in:

```text
app/public/assets/js/codeGraph/render.repaint.js
```

Typische Stellen sind:

- `nodeFill(d, enc)`
- `nodeStroke(d, enc)`
- `repaintHotspotHalos(...)`
- `repaintNodeBodies(...)`
- `repaintLabels(...)`

Das CSS ist dabei absichtlich entschärft, damit diese dynamischen Farben nicht wieder überschrieben werden.

---

# 13. Welche Felder im JSON entstehen

Für File-Nodes:

- `_changeFreq`
- `_lastTouchedAt`
- `_hotspotScore`
- `_hotspotRank`
- `hotspot`

Für Function-Nodes:

- dieselben Felder, vom Owner-File geerbt

Beispiel:

```json
{
  "id": "app/lib/parseAst.js",
  "kind": "file",
  "complexity": 172,
  "lines": 619,
  "_changeFreq": 47,
  "_lastTouchedAt": "2026-02-11T09:14:22.000Z",
  "_hotspotScore": 0.83,
  "_hotspotRank": 1,
  "hotspot": true
}
```

---

# 14. Welche Felder im CSV entstehen

Im CSV werden die Hotspot-Daten ebenfalls ausgegeben.

Relevante Spalten:

- `changeFreq`
- `lastTouchedAt`
- `hotspotScore`
- `hotspotRank`
- `hotspot`

Beispiel:

```csv
relation,kind,id,lines,complexity,changeFreq,hotspotScore,hotspotRank,hotspot
node,file,app/lib/parseAst.js,619,172,47,0.83,1,true
```

---

# 15. Wie Hotspots in der WebGUI dargestellt werden

Hotspots werden visuell kodiert über:

- **Node-Farbe**
- **Halo / Outline**
- **Badge**

## 15.1 Node-Farbe

Die Füllfarbe kommt aus der dynamischen Hotspot-Skala.

Stärkste Nodes:

- sehr kräftiges Magenta

Schwächere Nodes:

- helleres Rosa

## 15.2 Halo / Outline

Zusätzlich wird ein Halo um den Node gelegt.

Auch dieser verblasst mit sinkender Betonung.

## 15.3 Badge

Die Top 5 Hotspots bekommen zusätzlich ein Badge mit:

```text
Rang · CC
```

Beispiel:

- `1 · CC24`
- `2 · CC57`
- `3 · CC18`

Die visuelle Steuerung liegt verteilt auf:

- `app/public/assets/js/codeGraph/render.repaint.js`
- `app/public/assets/css/graph.css`

---

# 16. Was diese Heuristik gut erkennt

Die Metrik ist gut darin, folgende Kandidaten sichtbar zu machen:

- instabile Kernmodule
- komplexe Utility-Dateien mit vielen Änderungen
- Parser / Resolver / zentrale Infrastruktur-Dateien
- Bereiche mit hoher Wartungslast

Die Metrik hilft also besonders bei:

- Refactoring-Priorisierung
- Risikoabschätzung
- Architektur-Reviews

---

# 17. Grenzen der Heuristik

Die aktuelle Hotspot-Metrik ist bewusst pragmatisch.

Sie hat Grenzen:

## 17.1 Dateibasiert, nicht funktionsbasiert

Git liefert Änderungen auf Dateiebene.

Darum ist die Change Frequency nicht direkt pro Funktion messbar.

## 17.2 Keine Diff-Größe

Ein Commit zählt gleich, egal ob:

- 1 Zeile geändert wurde
- 300 Zeilen geändert wurden

## 17.3 Kein Zeitfenster

Aktuell wird die komplette Git-Historie verwendet.

Das bedeutet:

- alte historische Aktivität zählt weiter mit
- ein Modul kann historisch stark gewesen sein, aktuell aber ruhig

## 17.4 Keine semantische Qualität

Die Metrik kennt nicht:

- Bugfix vs. Feature
- riskante vs. harmlose Änderungen
- Testcode vs. Produktionscode

---

# 18. Mögliche Weiterentwicklungen

Für eine noch stärkere CodeScene-Nähe wären diese Erweiterungen sinnvoll:

## 18.1 Zeitfenster

Beispiel:

- letzte 3 Monate
- letzte 6 Monate
- letzte 12 Monate

Dann wird die Metrik aktueller.

## 18.2 Churn statt nur Commit Count

Nicht nur zählen, **wie oft** eine Datei vorkam, sondern auch:

- wie viele Zeilen hinzugefügt wurden
- wie viele Zeilen entfernt wurden

## 18.3 Funktions-Hotspots

Mit Blame- oder feineren Diff-Daten könnte man Hotspots näher an einzelne Funktionen bringen.

## 18.4 Zusätzliche kognitive Last

Erweiterungen wie:

- Nesting / Verschachtelung
- Fan-in / Fan-out
- Import-Zentralität
- Instabilität

würden den Score weiter verfeinern.

---

# 19. Kurzfassung

Der NodeAnalyzer verwendet aktuell diese Logik:

```text
1. Git-Historie lesen
2. pro Datei Commits zählen
3. Complexity und LOC normalisieren
4. kognitive Last berechnen
5. mit Change Frequency multiplizieren
6. Score ranken
7. Rang und CC zu einem Emphasis-Wert mischen
8. daraus Fill- und Outline-Farben interpolieren
9. Top-Hotspots farblich markieren
10. Top 5 mit Badge „Rang · CC" versehen
```

Die visuelle Gewichtung wird aktuell hier geregelt:

```text
0.6 × Rang + 0.4 × CC
```

und genau diese Mischung bestimmt, wie kräftig oder blass ein Hotspot im Graph erscheint.

---

# Ende

Diese Datei dokumentiert den aktuellen Hotspot-Algorithmus und die visuelle Hotspot-Skala des NodeAnalyzer.