

# Timeline Graph (Time View)

Der **Timeline Graph** zeigt die Entwicklung wichtiger Code‑Strukturmetriken über mehrere Analyse‑Runs einer App. 
Er visualisiert, wie sich die Architektur eines Projekts im Laufe der Zeit verändert.

Die Daten stammen aus den automatisch erzeugten CSV‑Dateien:

```
<appId>-<timestamp>-code-metrics.csv
```

Diese Dateien liegen im Ordner:

```
/public/output
```

Jede Datei repräsentiert **einen Analyse‑Run** der Anwendung.

---

# Wie der Graph entsteht

Der Graph wird im Frontend durch das Modul

```
public/assets/js/graph_timeView.js
```

aufgebaut.

Der Ablauf ist:

1. **Dateien ermitteln**

Das Frontend fragt das Backend:

```
/api/output-files?appId=<appId>&type=code-metrics
```

Das Backend liefert alle passenden CSV‑Dateien.


2. **CSV Dateien laden**

Für jede Datei wird geladen:

```
/output/<file>
```

Dies geschieht direkt über:

```
d3.csv()
```


3. **Metriken pro Run aggregieren**

Aus jeder CSV werden Werte für alle Code‑Module summiert:

| Metric | Bedeutung |
|------|------|
| loc | Lines of Code aller Module |
| fanIn | Anzahl eingehender Abhängigkeiten |
| fanOut | Anzahl ausgehender Abhängigkeiten |

Diese Werte werden pro Analyse‑Run aufsummiert.


4. **Zeitreihe bilden**

Aus jedem Run entsteht ein Datensatz:

```
{
  timestamp,
  loc,
  fanIn,
  fanOut
}
```

Diese werden nach Zeit sortiert.


5. **Stacked Area Chart rendern**

Der Graph wird mit **D3** als "Stacked Area Chart" gerendert.

Die Bereiche stellen dar:

```
fanOut
fanIn
loc
```

Alle drei werden übereinander gestapelt.

---

# Bedeutung der Punkte

Die schwarzen Punkte im Graph repräsentieren:

> **einen einzelnen Analyse‑Run**

Jeder Punkt steht für **eine CSV‑Datei**.

Der Punkt liegt auf der Höhe der **Summe aller Metriken dieses Runs**.

Beim Hover zeigt der Tooltip:

- Dateiname
- Timestamp
- Einzelwerte (loc / fanIn / fanOut)
- Gesamtsumme

Beispiel Tooltip:

```
nodeanalyzer-2026-03-10T12-35-01-455Z-code-metrics.csv
2026‑03‑10T12:35:01Z

loc: 12450
fanIn: 820
fanOut: 910

total: 14180
```

---

# Interpretation des Graphen

Der Graph hilft bei der **Architektur‑Beobachtung über Zeit**.

## LOC

Steigt `loc`, wächst der Codeumfang.

Das ist normal, aber starkes Wachstum kann auf

- Feature‑Expansion
- fehlende Modularisierung

hinweisen.


## fanOut

`fanOut` zeigt **wie viele Abhängigkeiten Module nach außen haben**.

Steigt dieser Wert stark, deutet das auf:

- steigende Kopplung
- komplexere Abhängigkeitsstruktur

hin.


## fanIn

`fanIn` zeigt **wie viele Module von anderen genutzt werden**.

Hoher fanIn bedeutet:

- zentrale Module
- mögliche "God‑Modules"


---

# Warum der Graph wichtig ist

Der Timeline Graph macht **Architektur‑Drift sichtbar**.

Man erkennt schnell:

- Wachstum der Codebasis
- steigende Kopplung
- strukturelle Änderungen
- Refactoring‑Effekte

Der Graph ist damit ein **Langzeit‑Monitor für Software‑Architektur**.


---

# Typische Muster

### Gesundes Projekt

```
loc     ↑ langsam
fanOut  → stabil
fanIn   → stabil
```


### Architektur driftet

```
loc     ↑
fanOut  ↑↑
fanIn   ↑
```


### Refactoring

```
loc     →
fanOut  ↓
fanIn   ↓
```


---

# Kurzfassung

Der Timeline Graph zeigt:

```
Zeit →

Stacked Architekturmetriken
(loc + fanIn + fanOut)
```

Jeder Punkt = **ein Analyse‑Run der App**.

Er erlaubt eine schnelle Einschätzung der **Architekturentwicklung über Zeit**.