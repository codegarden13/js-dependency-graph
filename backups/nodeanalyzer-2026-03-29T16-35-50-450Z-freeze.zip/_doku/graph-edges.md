

# CodeGraph – Edge Encoding

Diese Dokumentation beschreibt, wie **Edges (Kanten)** im CodeGraph farblich codiert werden und wie diese Codierung im **Encoder-Layer (`render.encoders.js`)** umgesetzt ist.

Die Edge-Codierung folgt denselben Designprinzipien wie die Node-Codierung:

- klare Trennung von **Daten → Encoding → Rendering**
- zentrale Definition aller Regeln im **Encoder**
- Farben werden über **CSS Variablen** gesteuert

---

## Edge Pipeline

Analyzer JSON → Graph Model → `render.encoders.js` → Renderer (`d3_codeStructure.js`) → SVG `<line>` / `<path>` Elemente

Der Encoder übersetzt Rohdaten aus dem Graphmodell in Farbe und breite der Edge.

---

### CSS-basierte Farbsteuerung

Alle Edge-Farben werden zentral über **CSS Custom Properties** definiert.

Beispiel:

```css
:root {

  --cg-edge-default: rgba(100,116,139,0.22);
  --cg-edge-changed: rgba(255,59,48,0.85);

  --cg-edge-call: rgba(99,102,241,0.30);
  --cg-edge-import: rgba(59,130,246,0.34);
  --cg-edge-export: rgba(34,197,94,0.34);
  --cg-edge-include: rgba(245,158,11,0.34);
  --cg-edge-use: rgba(168,85,247,0.30);

}
```

Diese Variablen werden im Encoder über `var(--...)` referenziert und mit einer smarten Funktion übersetzt.

---

### 3 Edge Encoding Schema

Die Farbe einer Edge codiert den **semantischen Beziehungstyp**.

| Edge Typ | Bedeutung | Farbe |
|--------|-----------|-------|
| call | Funktionsaufruf | Indigo |
| import | Modulimport | Blau |
| export | Exportierte API | Grün |
| include | Datei-Include | Orange |
| use | lose Nutzung / Referenz | Violett |
| default | generische Beziehung | Grau |

Zusätzlich:

| Zustand | Farbe |
|--------|------|
| `_changed` | Rot |

---

# 4 Ermittlung des Edge-Typs

Die Typbestimmung erfolgt in der Funktion:

```
getEdgeSemanticType(edge)
```

Diese Funktion liest verschiedene mögliche Felder aus dem Graphmodell:

```
edge.edgeType
edge.relation
edge.rel
edge.kind
edge.type
edge.label
```

Die Werte werden normalisiert:

```
normalizeToken(...values)
```

Danach erfolgt eine heuristische Klassifikation:

```
include → "include"
import  → "import"
export  → "export"
use     → "use"
call    → "call"
```

Wenn kein passender Typ erkannt wird:

```
"default"
```

---

# 5 Edge Farbe

Die eigentliche Farbzuweisung erfolgt in:

```
computeEdgeColor(edge)
```

Implementierung:

```
switch (getEdgeSemanticType(edge)) {
  case "call":
  case "import":
  case "export":
  case "include":
  case "use":
}
```

Die Farben werden aus dem zentralen Encoding Schema gelesen:

```
GRAPH_ENCODING.edge.callColor
GRAPH_ENCODING.edge.importColor
...
```

Da diese Werte CSS Variablen enthalten können, wird zusätzlich

```
resolveCssColor(...)
```

verwendet.

Diese Funktion löst `var(--...)` zur Laufzeit auf.

---

# 6 Edge Breite

Die Breite einer Edge codiert die **Stärke der Beziehung**.

Funktion:

```
computeEdgeWidth(edge)
```

Die Breite basiert auf einem Gewichtswert.

Mögliche Felder:

```
edge._weight
edge.weight
edge.count
edge.value
edge.strength
edge.calls
edge.uses
```

Diese werden über

```
readEdgeWeight(edge)
```

ermittelt.

---

# 7 Gewichtsnormierung

Edge-Gewichte können sehr unterschiedliche Skalen haben.

Darum wird eine logarithmische Normalisierung verwendet:

```
normalizeEdgeWeight01(rawWeight)
```

Formel:

```
log1p(weight) / log1p(reference)
```

Referenzwert:

```
GRAPH_ENCODING.edge.weightReference
```

Standard:

```
12
```

---

# 8 Breitenmapping

Die normierten Werte werden auf eine sichtbare Breite abgebildet:

```
minWidth → maxWidth
```

Standardwerte:

```
1px → 4px
```

Berechnung:

```
min + (max - min) * normalizedWeight
```

Sonderfall:

```
edge._changed === true
```

→ maximale Breite

---

# 9 Encoder API

Der Renderer greift über `makeEncoders()` auf die Edge-Encoding-Funktionen zu:

```
makeEncoders(nodes)
```

Das zurückgegebene Objekt enthält:

```
getEdgeColor
getEdgeWidth
```

Diese werden im Renderer verwendet:

```
.attr("stroke", enc.getEdgeColor(d))
.attr("stroke-width", enc.getEdgeWidth(d))
```

---

# 10 Designziel

Edges sollen im Graph **nicht dominieren**, sondern Struktur sichtbar machen.

Darum gilt:

- reduzierte Opacity
- dünne Linien
- semantische Farbgebung

Die Nodes bleiben das primäre visuelle Element.

Edges liefern zusätzliche Architekturinformation.

---

# 11 Vorteile dieses Ansatzes

- zentrales Encoding
- Theme über CSS steuerbar
- stabile Darstellung bei großen Graphen
- leicht erweiterbar für neue Beziehungstypen

Neue Edge-Typen können einfach ergänzt werden:

```
getEdgeSemanticType()
computeEdgeColor()
```

ohne Änderungen im Renderer.
