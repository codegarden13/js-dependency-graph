

# Graph Rendering Architektur

Dieses Dokument beschreibt die wichtigsten Rendering‑Komponenten des Code‑Dependency‑Graphen und deren Verantwortlichkeiten.

Der Rendering‑Stack ist bewusst in mehrere Schichten aufgeteilt:

1. **Scene / Renderer (d3_codeStructure.js)**
2. **Visual Encoding (render.encoders.js)**
3. **Repaint / Update Layer (render.repaint.js)**

Diese Trennung stellt sicher, dass

- Datenmodell
- visuelle Kodierung
- UI‑Updates

klar voneinander getrennt bleiben.

---

# 1. Scene Renderer

**Datei:**

```
d3_codeStructure.js
```

Diese Datei ist der **zentrale Renderer** und baut die komplette SVG‑Scene auf.

Hier wird der Graph initial erzeugt und die D3‑Simulation gestartet.

## Verantwortlichkeiten

- SVG initialisieren
- Layerstruktur erzeugen
- Nodes rendern
- Links rendern
- Labels erzeugen
- Hull‑Layer einfügen
- Force Simulation konfigurieren

Typischer Layer‑Aufbau:

```
svg
 ├─ g.hulls
 ├─ g.links
 ├─ g.nodes
 └─ g.labels
```

## Wichtige Funktionen

### Graph initialisieren

Initialisierung des gesamten Graph‑Renderings.

Typische Aufgaben:

- SVG erzeugen
- Zoom konfigurieren
- Layer erzeugen

Beispiel:

```js
const svg = d3.select("#codeStructureSvg");

const hullLayer = svg.append("g").attr("class", "hulls");
const linkLayer = svg.append("g").attr("class", "links");
const nodeLayer = svg.append("g").attr("class", "nodes");
const labelLayer = svg.append("g").attr("class", "labels");
```

---

### renderLinks()

Erzeugt alle Kanten des Graphen.

Aufgaben:

- `line` oder `path` Elemente erstellen
- Edge‑Typ Klassen setzen
- Encoder anwenden

Beispiel:

```js
linkLayer
  .selectAll("line")
  .data(links)
  .enter()
  .append("line")
  .attr("class", d => `link ${d.type}`)
```

---

### renderNodes()

Erzeugt alle Node‑Elemente.

Aufgaben:

- `g.codegraph-node` erzeugen
- Circle / Node Body rendern
- Radius setzen
- Farben setzen

Beispiel:

```js
nodeLayer
  .selectAll("g")
  .data(nodes)
  .enter()
  .append("g")
  .attr("class", "codegraph-node");
```

---

### renderLabels()

Erzeugt Node‑Labels.

Aufgaben:

- Text erzeugen
- Position relativ zum Node berechnen

---

### Simulation

Die D3 Force Simulation wird ebenfalls hier konfiguriert:

```js
simulation
  .nodes(nodes)
  .on("tick", ticked);
```

Im `tick` Handler werden Positionen aktualisiert:

```
node positions
edge positions
label positions
```

---

# 2. Visual Encoding Layer

**Datei:**

```
render.encoders.js
```

Diese Datei ist für die **visuelle Kodierung der Daten verantwortlich**.

Sie übersetzt Metriken des Graph‑Modells in visuelle Eigenschaften.

```
Daten → visuelle Darstellung
```

Beispiele:

| Daten | visuelle Eigenschaft |
|-----|----|
| Complexity | Node Radius |
| Edge Type | Edge Color |
| Coupling | Ring Width |

---

## Wichtige Encoder

### computeNodeRadius()

Berechnet die Node‑Größe basierend auf:

- Cyclomatic Complexity
- Container‑Komplexität

Formel basiert auf einer logarithmischen Normalisierung.

---

### computeNodeColor()

Bestimmt die Node‑Farbe basierend auf

- group
- kind
- type

Beispiele:

```
dir → blau
code → grau
helper → violett
```

---

### computeNodeStroke()

Bestimmt die Farbe des Node‑Rands.

Bedeutung:

| Farbe | Bedeutung |
|------|-----------|
| grün | exportiert |
| blau | importiert |
| türkis | shared |

---

### computeNodeStrokeWidth()

Randbreite basiert auf **Coupling**:

```
f(anbindungen)
```

---

### getFunctionRingWidth()

Bestimmt die Breite des Funktionsrings.

Berechnung basiert auf

```
(inboundCalls + outboundCalls)
```

---

### computeEdgeColor()

Bestimmt Edge‑Farben basierend auf dem Link‑Typ.

Mapping:

```
call     → violett
use      → blau
include  → orange
extends  → grün
```

---

### computeEdgeWidth()

Edge‑Breite wird aus

```
weight / call count
```

abgeleitet.

---

# 3. Repaint Layer

**Datei:**

```
render.repaint.js
```

Dieser Layer ist für **Updates eines bereits gerenderten Graphen** zuständig.

Er erzeugt **keine neuen DOM‑Elemente**, sondern aktualisiert bestehende.

Das wird verwendet für:

- Filter
- Hotspots
- Interaktionszustände
- Selektion

---

## makeRepaint()

Erzeugt eine Sammlung von Repaint‑Funktionen.

Diese werden vom UI‑Layer aufgerufen.

```
makeRepaint()
   ↓
repaintNodes()
repaintEdges()
repaintLabels()
repaintHotspots()
```

---

## repaintNodes()

Aktualisiert

- Node Radius
- Node Color
- Node Stroke

---

## repaintEdges()

Aktualisiert

- Edge Farbe
- Edge Breite

Typische Nutzung:

```
Filter
Hotspot Highlight
```

---

## repaintHotspots()

Setzt spezielle Styles für Hotspot‑Nodes.

Beispiele:

- Badge anzeigen
- Halo aktivieren
- Node‑Stroke verstärken

---

# Zusammenspiel der Komponenten

Der gesamte Rendering‑Flow sieht so aus:

```
Graph JSON
      ↓
d3_codeStructure.js
(Scene Aufbau)
      ↓
render.encoders.js
(visuelle Parameter)
      ↓
SVG DOM
      ↓
render.repaint.js
(Update / UI Interaktionen)
```

---

# Ziel dieser Architektur

Die Aufteilung sorgt für:

- klare Verantwortlichkeiten
- bessere Wartbarkeit
- einfachere UI‑Updates
- isolierte Visual‑Encoding‑Logik

Damit kann das Rendering‑System erweitert werden ohne

- den Scene Renderer zu verändern
- oder UI‑Logik in Rendering‑Code zu mischen.
