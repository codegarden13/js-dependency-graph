# Architecture MRI Graph

Der **MRI Graph** ist eine Visualisierung der Architektur eines Projekts. 
Er kombiniert strukturelle Informationen (Module und Abhängigkeiten) mit Risiko‑Signalen aus den Metriken der Analyse.

Die Datenbasis ist die jeweils **neueste `code-metrics.csv`** Datei aus dem Verzeichnis:

```
/public/output
```

Diese Datei wird beim Öffnen des MRI‑Tabs geladen und daraus wird der Graph erzeugt.

---

# Wie der Graph entsteht

Der Graph wird in mehreren Schritten aufgebaut:

### 1 Daten laden

Der Browser fragt zuerst die verfügbaren Analyse‑Dateien ab:

```
/api/output-files?appId=<appId>&type=code-metrics
```

Danach wird die **neueste `*-code-metrics.csv` Datei** geladen.


### 2 Nodes erzeugen

Jede Zeile der CSV, die eine **Code‑Datei** repräsentiert, wird zu einem Node.

Typische Felder der CSV:

```
id
file
lines
complexity
hotspotScore
changeFreq
layer
x
y
```

Nur Dateien mit typischen Code‑Endungen werden berücksichtigt:

```
.js
.ts
.jsx
.tsx
.mjs
.cjs
```


### 3 Links erzeugen

Zeilen mit

```
source
 target
```

werden als **Abhängigkeiten zwischen Modulen** interpretiert.

Diese bilden die Kanten im Graph.


### 4 Layout bestimmen

Es gibt zwei Möglichkeiten:

#### vorhandene Koordinaten

Wenn in der CSV bereits

```
x
 y
```

vorhanden sind, werden diese benutzt.

Dann bleibt der Graph stabil und reproduzierbar.


#### automatisch berechnetes Layout

Wenn keine Koordinaten existieren, wird ein **Force Layout** berechnet:

- Repulsion zwischen Nodes
- Link Kräfte
- Kollisionsvermeidung

Danach wird das Ergebnis **statisch gerendert**.


---

# Was der Graph darstellt

Der MRI Graph zeigt gleichzeitig mehrere Architektur‑Signale.

Jeder **Knoten repräsentiert ein Modul / eine Datei**.

Die Darstellung kodiert mehrere Metriken gleichzeitig.


## Node Größe

```
lines
```

Große Kreise = große Dateien.


## Node Farbe

```
hotspotScore
```

Farben reichen von

```
gelb → orange → rot
```

Je roter ein Modul ist, desto stärker gilt es als **Architektur‑Hotspot**.


## Randstärke

```
fanOut
```

Das ist die Anzahl der **ausgehenden Abhängigkeiten**.

Dicke Ränder bedeuten:

> Dieses Modul hängt von vielen anderen Modulen ab.


## Roter Halo

```
changeFreq
```

Der rote Ring zeigt **Änderungsdruck**.

Großer Halo = Modul wird häufig geändert.


## Linien

Linien stellen **Abhängigkeiten zwischen Modulen** dar.

```
source → target
```

Je dichter das Netzwerk, desto stärker sind Module miteinander gekoppelt.


## Labels

Die wichtigsten Module erhalten Beschriftungen.

Diese werden anhand eines **Importance Scores** ausgewählt.

Der Score kombiniert:

```
hotspotScore
changeFreq
complexity
lines
```


---

# Warum der Graph eine "MRI" ist

Der Name kommt aus der Medizin.

Ein MRI zeigt nicht nur die Oberfläche, sondern **verborgene Strukturen und Spannungen**.

Genauso zeigt dieser Graph nicht nur:

```
wer importiert wen
```

sondern auch:

- Architektur‑Hotspots
- komplexe Module
- große Dateien
- Änderungsdruck
- starke Kopplungen


---

# Interpretation

Typische Muster im Graph:

### kompakte Kugel

Viele Module sind stark miteinander gekoppelt.

Das deutet auf:

- fehlende Modulgrenzen
- hohe gegenseitige Abhängigkeit


### große rote Knoten

Große Module mit hohem HotspotScore.

Typischerweise Kandidaten für:

```
Refactoring
Modultrennung
```


### große Halos

Module mit hoher Änderungsfrequenz.

Diese sind häufig **Wartungsschwerpunkte**.


### dicke Ränder

Module mit vielen ausgehenden Abhängigkeiten.

Diese sind häufig **Orchestrierungs‑ oder Service‑Layer**.


---

# Legende

| Visualisierung | Bedeutung |
|---|---|
| Kreisgröße | Anzahl Codezeilen (`lines`) |
| Farbe | Architektur‑Hotspot (`hotspotScore`) |
| Randstärke | Anzahl ausgehender Abhängigkeiten (`fanOut`) |
| Roter Halo | Änderungsfrequenz (`changeFreq`) |
| Linie | Modulabhängigkeit |
| Label | wichtiges Modul |


---

# Wie man den Graph verändert

Der Graph kann auf verschiedene Arten beeinflusst werden.


## Graph vergrößern

Im HTML kann das SVG größer gemacht werden:

```
<svg id="graphMriView" width="1600" height="1000"></svg>
```


## Layout verändern

Im Code kann das Force‑Layout angepasst werden:

Beispiele:

```
forceManyBody().strength(-200)
```

stärkeres Auseinanderziehen.


```
forceLink().distance(120)
```

mehr Abstand zwischen Modulen.


## Anzahl Labels erhöhen

Aktuell werden nur die wichtigsten Nodes beschriftet.

Diese Zahl kann im Code erhöht werden.


## andere Metriken visualisieren

Die Darstellung kann leicht angepasst werden, z.B.

Node Größe:

```
complexity
```

Node Farbe:

```
changeFreq
```


---

# Ziel des MRI Graph

Der Graph soll helfen, schnell zu erkennen:

- wo Architektur‑Risiken liegen
- welche Module zentral sind
- welche Teile des Systems instabil sind
- wo Refactoring sinnvoll wäre

Er ist daher **kein exakter Architekturplan**, sondern ein Werkzeug zur **Architekturdiagnose**.

