

# Graph Generation – NodeAnalyzer

```txt
routes/
├── analyze.js   → startet Analyse
├── apps.js      → liefert App-Konfiguration
```

Wenn der Analyze-Run vom Frontend gestartet wird, kannst du dort einen Screenshot machen.


Diese Dokumentation beschreibt, wie der Code‑Graph im NodeAnalyzer entsteht, welche Daten er enthält und wie diese im Frontend visualisiert werden.

Die Darstellung basiert auf **D3 Force Layout** und wird vollständig aus den vom Backend erzeugten **Metrics (JSON)** generiert.

---

## 1. Überblick

Der Graph stellt die **Struktur einer Codebasis** dar.

Er visualisiert:

- Dateien
- Funktionen
- Abhängigkeiten
- Code‑Komplexität
- Änderungsaktivität (Hotspots)

Der Graph ist kein statischer Baum, sondern ein **Force‑Directed Network Graph**.

Das bedeutet:

- Nodes stoßen sich gegenseitig ab
- Links ziehen verbundene Nodes zusammen
- Cluster entstehen automatisch

---

## 2. Datenquelle des Graphen

Der Graph basiert auf einer **Analyse des Projekts**.

Analyse‑Pipeline:

```
/analyze
   ↓
AST Analyse
   ↓
Metrics erzeugen
   ↓
Hotspots berechnen
   ↓
JSON + CSV Export
   ↓
Frontend Graph Render in 
```

Das Ergebnis wird gespeichert unter:

```
/app/public/output/code-structure-<runToken>.json
```

---

## 3. Struktur der Graphdaten

Die Graphdaten bestehen aus zwei zentralen Arrays:

```
nodes[]
links[]
```

Beispiel:

```json
{
  "nodes": [...],
  "links": [...]
}
```

---

## 4. Nodes

Nodes repräsentieren **Code‑Elemente**.

Typische Node‑Typen:

| Typ | Bedeutung |
|----|----|
| root | Projekt Root |
| dir | Verzeichnis |
| file | Datei |
| function | Funktion |


Beispiel Node:

```json
{
  "id": "app/lib/parser.js",
  "kind": "file",
  "group": "code",
  "lines": 312,
  "complexity": 24,
  "hotspot": true,
  "_hotspotScore": 0.82
}
```
In  render.repaint.js wird (derzeit) ausschließlich Node-bezogenes Rendering aktualisiert.
---

## 5. Links

Links beschreiben Beziehungen zwischen Nodes.

Typische Beziehungen:

| Typ | Bedeutung |
|----|----|
| include | Datei importiert Datei |
| call | Funktion ruft Funktion |
| contain | Datei enthält Funktion |


Beispiel:

```json
{
  "source": "app/server.js",
  "target": "app/lib/router.js",
  "type": "include"
}
```
[ Hier](graph-edges.md) wird genauer beschrieben

	•	Edge-Farbcodierung (call, import, export, include, use, default)
	•	CSS-basierte Farbsteuerung über style.css
	•	Edge-Typ-Erkennung (getEdgeSemanticType)
	•	Edge-Farbberechnung (computeEdgeColor)
	•	Edge-Breitenberechnung (computeEdgeWidth)
	•	Gewichtsnormierung (normalizeEdgeWeight01)
	•	Renderer-Integration über makeEncoders()


## 6. Visualisierung mit **D3.js**

Zentrale Render‑Module:

```
d3_codeStructure.js
render.encoders.js
render.repaint.js
render.simulation.js
```

---

## 7. Node Darstellung

Nodes werden als **Kreise** dargestellt.

Radius basiert auf:

```
complexity
+ lines
+ child function complexity
```

Das ergibt eine **Codegröße / kognitive Last**.

---

## 8. Node Farben

Die Grundfarbe wird durch `group` bestimmt.

Typische Gruppen:

| group | Farbe |
|----|----|
| root | neutral |
| dir | grau |
| code | blau |
| doc | grün |
| data | orange |


---

[Hotspots](graph-hotspots.md) werden visuell hervorgehoben.

[Node - Ringe um die Funktionen](graph-nodesRings.md) signalisieren Exporte (grün) und Importe (Türkis).



---

## 12. Simulation

Das Layout wird durch eine **Force Simulation** erzeugt.

Verwendete Kräfte:

```
forceLink
forceManyBody
forceCenter
forceCollide
```

Dadurch entstehen automatisch Cluster nach:

- Verzeichnis
- Modul
- Abhängigkeiten

---

## 13. Cluster Hulls

Verwandte Nodes werden von **Hull Shapes** umgeben.

Diese zeigen Cluster wie:

- Module
- Verzeichnisse

Renderer:

```
render.hulls.js
```

---

## 14. Labels

Nodes besitzen Textlabels.

Labelinhalt:

```
Dateiname
oder
Funktionsname
```

---

## 15. Tooltips

Beim Hover erscheinen Tooltips.

Diese enthalten:

- Name
- Dateipfad
- Komplexität
- LOC
- Hotspot Score

Renderer:

```
render.tooltip.js
```

---

## 16. Interaktionen

Der Graph unterstützt:

- Zoom
- Pan
- Node Selection
- Highlight

Interaktionsmodul:

```
CodeGraphInteractions
```

---

## 17. Live Updates

Dateiänderungen werden über **Server Sent Events** übertragen.

Endpoint:

```
/events
```

Bei Änderung:

- Node wird markiert
- Node erhält temporäre Highlight Farbe

---

## 18. Repaint Pipeline

Wenn sich Daten ändern, wird der Graph nicht neu aufgebaut.

Stattdessen läuft eine Repaint‑Pipeline:

```
makeRepaint()
   ↓
repaintNodeBodies()
   ↓
repaintLabels()
   ↓
repaintHotspotBadges()
```

Dies sorgt für sehr schnelle Updates.

---

## 19. CSV Export

Zusätzlich zum JSON wird ein CSV erzeugt.

Enthalten sind:

- Nodes
- Links
- Komplexität
- Change Frequency
- Hotspot Score

Beispiel:

```
relation,kind,id,lines,complexity,changeFreq,hotspotScore
node,file,app/server.js,200,35,14,0.76
```

---

## 20. Ziel des Graphen

Der Graph dient dazu, schnell zu erkennen:

- strukturelle Probleme
- komplexe Module
- Hotspots
- tote Funktionen
- Architekturabhängigkeiten

Er ist damit ein **Architektur‑Analysewerkzeug für Codebasen**.

---

# Ende

Diese Dokumentation beschreibt den aktuellen Stand der Graph‑Generierung im NodeAnalyzer.